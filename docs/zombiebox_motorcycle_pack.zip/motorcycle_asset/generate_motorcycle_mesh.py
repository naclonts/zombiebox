#!/usr/bin/env python3
"""Original retro cruiser asset, Y up / +Z forward, metres. numpy, trimesh, Pillow.
Run: python3 generate_motorcycle_mesh.py [output-directory]
"""
from pathlib import Path
import sys, math, json
import struct
from collections import defaultdict
import numpy as np
import trimesh
from PIL import Image, ImageDraw
OUT=Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).resolve().parent
OUT.mkdir(parents=True,exist_ok=True)
P={ 'body':[], 'steering':[], 'front_wheel':[], 'rear_wheel':[] }
PIV={'body':(0,0,0),'steering':(0,.99,.48),'front_wheel':(0,.35,.835),'rear_wheel':(0,.345,-.835)}
# Attachment origins in model meters, relative to the named part's pivot.
# With the game's +Z-forward model alignment, rider-right is model -X.
LOCATORS = {
    "seat": ("body", (0.0, 0.752, -0.34)),
    "grip_left": ("steering", (0.3875, 0.19, -0.2625)),
    "grip_right": ("steering", (-0.3875, 0.19, -0.2625)),
    "footboard_left": ("body", (0.224, 0.303, 0.16)),
    "footboard_right": ("body", (-0.224, 0.303, 0.16)),
}
# Indices 0..2 are paint slots: primary, secondary, pinstripe.
COLORS=[(40,91,69),(24,28,29),(165,137,74),(31,32,32),(15,17,17),(52,55,53),(155,163,163),(204,210,207),(98,106,106),(72,75,73),(207,200,165),(137,40,32),(203,121,37),(31,27,24),(106,110,106)]
SCHEMES={'green_black':[(38,91,67),(24,29,30),(172,144,82)],'burgundy_black':[(113,35,43),(25,27,29),(177,143,79)],'cream_black':[(204,190,154),(27,31,31),(151,117,60)],'midnight_blue':[(41,69,105),(22,27,33),(151,166,177)],'matte_black':[(49,51,51),(20,22,23),(105,105,103)]}
PAINT,SECOND,STRIPE,BLACK,RUBBER,FRAME,CHROME,HI,STEEL,DARK,LAMP,RED,AMBER,SEAT,FIN=range(len(COLORS))
def unit(v):
    v=np.array(v,float);return v/np.linalg.norm(v)
def tri(part,a,b,c,m,out=None):
    a,b,c=np.array([a,b,c],float); n=np.cross(b-a,c-a)
    if np.linalg.norm(n)<=1.5e-6:return
    if out is not None and n@out<0:b,c=c,b
    P[part].append((np.array([a,b,c]),m))
def quad(p,a,b,c,d,m,out=None):
    tri(p,a,b,c,m,out);tri(p,a,c,d,m,out)
def cap(p,ring,center,m,out):
    for i in range(len(ring)):tri(p,center,ring[i],ring[(i+1)%len(ring)],m,out)
def beam(p,a,b,r1,r2,m,n=10):
    a,b=np.array(a,float),np.array(b,float);v=unit(b-a);u=unit(np.cross(v,[0,0,1] if abs(v[2])<.9 else [1,0,0]));w=np.cross(v,u)
    angles=np.arange(n)*2*np.pi/n;dirs=np.array([u*np.cos(t)+w*np.sin(t) for t in angles]);A=a+r1*dirs;B=b+r2*dirs
    for i in range(n):
        j=(i+1)%n;quad(p,A[i],A[j],B[j],B[i],m,dirs[i]+dirs[j])
    cap(p,A,a,m,-v);cap(p,B,b,m,v)
def pipe(p,points,r,m,n=9):
    # connected sweep, bisected tangents, consistent frame for bends in YZ or XY plane
    pts=np.array(points,float);rings=[];dirs=[]
    for i,c in enumerate(pts):
        v=unit(pts[min(i+1,len(pts)-1)]-pts[max(i-1,0)]); ref=np.array([1,0,0]) if abs(v[0])<.95 else np.array([0,0,1]);u=unit(ref-v*(ref@v));w=np.cross(v,u);dirs.append(v)
        rings.append(np.array([c+r*(u*np.cos(t)+w*np.sin(t)) for t in np.arange(n)*2*np.pi/n]))
    for i in range(len(rings)-1):
        for j in range(n):
            k=(j+1)%n;a,b,c,d=rings[i][j],rings[i][k],rings[i+1][k],rings[i+1][j];quad(p,a,b,c,d,m,(a+b+c+d)/4-(pts[i]+pts[i+1])/2)
    cap(p,rings[0],pts[0],m,-dirs[0]);cap(p,rings[-1],pts[-1],m,dirs[-1])
def box(p,c,size,m):
    mesh=trimesh.creation.box(extents=size);mesh.apply_translation(c)
    for f in mesh.faces:tri(p,*mesh.vertices[f],m)
def ell(p,c,scale,m,sub=1):
    mesh=trimesh.creation.icosphere(subdivisions=sub);mesh.vertices*=scale;mesh.vertices+=c
    for f in mesh.faces:tri(p,*mesh.vertices[f],m)
def loft(p,sections,m,n=20,twotone=False):
    # cross sections (z,centerY,halfWidth,halfHeight); long axis Z
    if twotone:
        angles=np.array([0,.22,.26,.52,.78,1.05,1.31,1.57,1.83,2.09,2.36,2.62,2.88,2.92,3.14,3.40,3.67,3.93,4.19,4.45,4.71,4.97,5.24,5.50,5.76,6.02])
    else:angles=np.arange(n)*2*np.pi/n
    rings=[np.array([[w*np.cos(t),y+h*np.sin(t),z] for t in angles]) for z,y,w,h in sections];n=len(angles)
    for j in range(len(rings)-1):
        for i in range(n):
            k=(i+1)%n;t=(angles[i]+(angles[k] if k else 2*np.pi))/2
            mat=m
            if twotone:mat=STRIPE if i in (1,12) else (PAINT if np.sin(t)>.24 else SECOND)
            quad(p,rings[j][i],rings[j][k],rings[j+1][k],rings[j+1][i],mat,np.array([np.cos(t),np.sin(t),0]))
    cap(p,rings[0],(0,sections[0][1],sections[0][0]),m,(0,0,-1));cap(p,rings[-1],(0,sections[-1][1],sections[-1][0]),m,(0,0,1))
def lathe(p,y,z,profile,materials,n=40):
    # closed wheel cross-section (x, radius); profile order outward from left inner side
    a=np.arange(n)*2*np.pi/n; rows=[np.array([[x,y+r*np.cos(t),z+r*np.sin(t)] for t in a]) for x,r in profile]
    # signed polygon area for outward cross-section normal in (x,r)
    sign=np.sign(sum(profile[i][0]*profile[(i+1)%len(profile)][1]-profile[(i+1)%len(profile)][0]*profile[i][1] for i in range(len(profile))))
    for j,(x,r) in enumerate(profile):
        k=(j+1)%len(profile);dx=profile[k][0]-x;dr=profile[k][1]-r
        for i in range(n):
            h=(i+1)%n;t=a[i]+np.pi/n;out=sign*np.array([dr,-dx*np.cos(t),-dx*np.sin(t)]);quad(p,rows[j][i],rows[j][h],rows[k][h],rows[k][i],materials[j],out)
def wheel(p,front):
    _,y,z=PIV[p]; R=y; w=.075 if front else .091; inner=.244 if front else .220
    lathe(p,y,z,[(-w*.72,inner),(-w,inner+.037),(-w,R-.037),(-w*.73,R-.010),(-w*.30,R),(w*.30,R),(w*.73,R-.010),(w,R-.037),(w,inner+.037),(w*.72,inner)], [RUBBER,BLACK,RUBBER,RUBBER,RUBBER,RUBBER,RUBBER,BLACK,RUBBER,RUBBER])
    lathe(p,y,z,[(-w*.77,inner-.021),(-w*.77,inner+.008),(-w*.47,inner+.016),(w*.47,inner+.016),(w*.77,inner+.008),(w*.77,inner-.021)], [CHROME,HI,STEEL,HI,CHROME,STEEL])
    beam(p,(-w*.76,y,z),(w*.76,y,z),.069,.069,STEEL,18)
    beam(p,(-w-.017,y,z),(w+.017,y,z),.029,.029,CHROME,12)
    for s in [-1,1]:
        for i in range(16):
            t=2*np.pi*i/16; t2=t+(0.23 if i%2 else -.23)
            beam(p,(s*w*.67,y+.047*np.cos(t2),z+.047*np.sin(t2)),(s*w*.64,y+(inner-.012)*np.cos(t),z+(inner-.012)*np.sin(t)),.0043,.0043,CHROME,5)
    if front:
        # front single brake disc with dark inner carrier
        x=-w-.009;lathe(p,y,z,[(x-.005,.078),(x-.005,.143),(x+.005,.143),(x+.005,.078)],[STEEL,HI,STEEL,DARK],32)
        for i in range(6):
            t=i*np.pi/3;beam(p,(x-.005,y+.054*np.cos(t),z+.054*np.sin(t)),(x-.005,y+.10*np.cos(t+.15),z+.10*np.sin(t+.15)),.009,.009,STEEL,6)
    else:beam(p,(-w-.018,y,z),(-w+.006,y,z),.112,.112,STEEL,20)
def fender(p,y,z,R,w,start,end):
    # solid arched valanced shell. theta 0 = top, positive = forward.
    N=28; angles=np.linspace(np.radians(start),np.radians(end),N+1)
    # outer cross section arcs into side skirts. black lower panels with gold pinstripe
    cross=[(-w,R-.057),(-w,R-.015),(-w*.98,R-.009),(-w*.93,R+.001),(-w*.64,R+.023),(0,R+.035),(w*.64,R+.023),(w*.93,R+.001),(w*.98,R-.009),(w,R-.015),(w,R-.057)]
    mats=[SECOND,STRIPE,PAINT,PAINT,PAINT,PAINT,PAINT,PAINT,STRIPE,SECOND]
    rows=[]
    for i,t in enumerate(angles):
        taper=.92+.08*np.sin(np.pi*i/N)
        rows.append(np.array([[x*taper,y+r*np.cos(t),z+r*np.sin(t)] for x,r in cross]))
    for i in range(N):
        t=(angles[i]+angles[i+1])/2
        for j in range(len(cross)-1):
            xmid=(cross[j][0]+cross[j+1][0])/2;out=np.array([np.sign(xmid)*.85,np.cos(t),np.sin(t)])
            quad(p,rows[i][j],rows[i+1][j],rows[i+1][j+1],rows[i][j+1],mats[j],out)
    # underside follows outer shape with thin inward offset; open only at the fender ends/edges, capped there
    inner=[np.array([[x*.96,y+(r-.008)*np.cos(t),z+(r-.008)*np.sin(t)] for x,r in cross]) for t in angles]
    for i in range(N):
        t=(angles[i]+angles[i+1])/2
        for j in range(len(cross)-1):
            xmid=(cross[j][0]+cross[j+1][0])/2;quad(p,inner[i][j],inner[i+1][j],inner[i+1][j+1],inner[i][j+1],SECOND,[-np.sign(xmid)*.85,-np.cos(t),-np.sin(t)])
        for j,s in [(0,-1),(-1,1)]:quad(p,rows[i][j],inner[i][j],inner[i+1][j],rows[i+1][j],SECOND,[s,0,0])
    for i,s in [(0,-1),(-1,1)]:
        t=angles[i];out=s*np.array([0,-np.sin(t),np.cos(t)])
        for j in range(len(cross)-1):quad(p,rows[i][j],rows[i][j+1],inner[i][j+1],inner[i][j],SECOND,out)
# Main chassis
p='body';wheel('rear_wheel',False);wheel('front_wheel',True)
fender(p,.345,-.835,.373,.115,-114,53)
# double cradle frame and backbone
for s in [-1,1]:
    x=s*.115
    pipe(p,[(x,.90,.40),(x,.72,.35),(x,.40,.30),(x,.225,.14),(x,.225,-.30),(x,.41,-.47),(x,.65,-.37)],.024,FRAME)
    pipe(p,[(x,.63,-.33),(x,.61,-.60),(x,.45,-.81)],.021,FRAME)
    beam(p,(x,.33,-.30),(s*.125,.345,-.835),.027,.022,FRAME)
    # rear coil-over shocks and chrome springs as rings
    a=np.array([s*.143,.41,-.75]);b=np.array([s*.143,.68,-.49]);v=unit(b-a)
    beam(p,a,b,.024,.024,STEEL);beam(p,a,a+.115*v,.037,.037,CHROME)
    for i in range(8):
        c=a+(.13+i*.022)*v;beam(p,c,c+.010*v,.040,.040,HI,12)
    # passenger pegs and floorboards
    beam(p,(s*.12,.42,-.51),(s*.25,.42,-.51),.019,.019,BLACK,8)
    box(p,(s*.224,.272,.16),(.16,.032,.26),STEEL);box(p,(s*.224,.294,.16),(.145,.018,.23),RUBBER)
beam(p,(0,.68,-.42),(0,.96,.45),.044,.045,FRAME)
# fuel tank: rounded teardrop, two-tone panels, subtle pinstripe
loft(p,[(-.31,.805,.036,.036),(-.23,.831,.115,.076),(-.11,.865,.174,.115),(.08,.895,.202,.145),(.26,.922,.174,.143),(.39,.921,.112,.105),(.46,.902,.040,.049)],PAINT,twotone=True)
beam(p,(0,1.039,.13),(0,1.061,.13),.045,.044,CHROME,18)
# tank dash and speedometer
ell(p,(0,1.027,.29),(.064,.027,.083),CHROME);beam(p,(0,1.048,.29),(0,1.059,.29),.044,.044,BLACK,16)
# low scooped rider saddle and passenger seat
loft(p,[(-.64,.731,.06,.03),(-.57,.741,.12,.043),(-.47,.716,.176,.045),(-.34,.708,.177,.044),(-.23,.74,.123,.042),(-.17,.785,.050,.030)],SEAT,16)
loft(p,[(-.91,.744,.035,.021),(-.84,.77,.105,.047),(-.70,.785,.123,.048),(-.60,.78,.086,.042),(-.56,.76,.04,.023)],SEAT,14)
# side covers beneath saddle
for s in [-1,1]:ell(p,(s*.117,.56,-.39),(.074,.115,.16),SECOND)
# V twin cylinders (two angled finned banks), crankcase and chrome rocker boxes
ell(p,(0,.385,-.015),(.18,.145,.21),STEEL,2)
for direction in [-1,1]:
    a=np.array([0,.40,-.015]);v=unit([0,1,direction*.53]);b=a+.30*v
    beam(p,a,b,.102,.100,DARK,12)
    for i in range(8):
        c=a+(.075+.025*i)*v;beam(p,c,c+.011*v,.139,.139,FIN,14)
    beam(p,b-.035*v,b+.026*v,.139,.133,CHROME,14)
    beam(p,b+.026*v,b+.055*v,.133,.116,HI,14)
for s in [-1,1]:
    beam(p,(s*.13,.39,-.02),(s*.196,.39,-.02),.108,.104,CHROME,20)
    beam(p,(s*.196,.39,-.02),(s*.207,.39,-.02),.081,.081,HI,20)
    ell(p,(s*.153,.54,.01),(.078,.095,.108),CHROME)
# radiator between front frame downtubes
box(p,(0,.49,.335),(.205,.24,.052),DARK)
for i in range(8):box(p,(0,.387+i*.028,.366),(.185,.009,.008),STEEL)
# twin staggered side exhausts; deep dark tips with chrome lip
for y,z0,zend in [(.265,.22,-1.09),(.354,-.18,-1.17)]:
    pipe(p,[(.12,.60,z0),(.22,.56,z0+.09),(.249,.43,z0+.13),(.249,y+.05,z0+.06),(.249,y,z0-.10),(.249,y,zend+.17)],.030,CHROME,12)
    beam(p,(.249,y,zend+.55),(.249,y,zend),.048,.048,CHROME,16)
    # recessed circular black tip, avoiding coplanarity
    beam(p,(.249,y,zend-.001),(.249,y,zend-.007),.035,.035,BLACK,16)
# taillight and rear indicators
ell(p,(0,.485,-1.184),(.071,.052,.035),RED)
box(p,(0,.405,-1.185),(.132,.067,.018),STEEL);box(p,(0,.405,-1.196),(.115,.052,.006),(LAMP))
for s in [-1,1]:
    beam(p,(s*.09,.52,-1.025),(s*.20,.52,-1.025),.012,.012,CHROME)
    beam(p,(s*.20,.52,-1.005),(s*.20,.52,-1.044),.034,.034,CHROME,12)
    beam(p,(s*.20,.52,-1.044),(s*.20,.52,-1.054),.027,.027,AMBER,12)
# Steerable assembly: fork, fender, headlight, bar & mirrors
p='steering'; fender(p,.35,.835,.374,.096,-83,95)
for s in [-1,1]:
    x=s*.116; a=np.array([x,.35,.835]); b=np.array([x,1.00,.475]);v=unit(b-a)
    beam(p,a,b,.025,.025,CHROME,14);beam(p,a,a+.37*v,.044,.044,STEEL,14);beam(p,a+.35*v,a+.40*v,.047,.047,CHROME,14)
    beam(p,a+.405*v,b,.031,.031,HI,12)
    # fender strut
    beam(p,(s*.102,.50,.77),(s*.103,.63,.87),.015,.015,CHROME)
beam(p,(-.145,.905,.53),(.145,.905,.53),.043,.043,CHROME,12)
beam(p,(-.145,.99,.48),(.145,.99,.48),.032,.032,CHROME,12)
# headlamp bucket with rim / lens pointing +Z
beam(p,(0,.93,.55),(0,.93,.685),.060,.103,CHROME,24)
beam(p,(0,.93,.685),(0,.93,.719),.105,.105,HI,24)
beam(p,(0,.93,.719),(0,.93,.729),.091,.091,LAMP,24)
for s in [-1,1]:
    beam(p,(s*.07,.99,.48),(s*.07,1.08,.47),.021,.021,CHROME)
    pipe(p,[(s*.065,1.08,.47),(s*.15,1.10,.445),(s*.23,1.15,.36),(s*.31,1.18,.27),(s*.375,1.18,.225)],.016,CHROME,10)
    beam(p,(s*.33,1.18,.255),(s*.445,1.18,.18),.026,.025,RUBBER,12)
    beam(p,(s*.438,1.18,.185),(s*.454,1.18,.174),.027,.027,CHROME,12)
    # clutch/brake lever and mirror stalk
    pipe(p,[(s*.32,1.18,.28),(s*.38,1.18,.32),(s*.445,1.18,.26)],.008,CHROME,7)
    pipe(p,[(s*.32,1.18,.28),(s*.36,1.30,.32),(s*.42,1.34,.30)],.009,CHROME,8)
    ell(p,(s*.43,1.36,.30),(.067,.038,.020),CHROME)
    ell(p,(s*.43,1.36,.281),(.058,.031,.006),STEEL)
    beam(p,(s*.13,.83,.60),(s*.22,.83,.60),.013,.013,CHROME)
    beam(p,(s*.22,.83,.59),(s*.22,.83,.65),.034,.034,CHROME,12)
    beam(p,(s*.22,.83,.65),(s*.22,.83,.659),.028,.028,AMBER,12)
# brake caliper on fork
box(p,(-.11,.45,.775),(.061,.082,.055),DARK)

# All exports share exact, rounded coordinates; filter tiny triangles to match MeshBuffer::validate.
for part,items in P.items():
    pivot=np.array(PIV[part]); cleaned=[]
    for a,m in items:
        a=np.round(a-pivot,6).astype(np.float32);cross=np.cross(a[1]-a[0],a[2]-a[0])
        if cross@cross>1.05e-12:cleaned.append((a,m))
    P[part]=cleaned

def palette(name):return SCHEMES[name]+COLORS[3:]
def scene_for(name):
    sc=trimesh.Scene(); pal=palette(name)
    for part,items in P.items():
        v=np.concatenate([a for a,m in items]);f=np.arange(len(v)).reshape(-1,3);c=np.repeat(np.array([(*pal[m],255) for a,m in items],np.uint8),3,axis=0)
        mesh=trimesh.Trimesh(vertices=v,faces=f,vertex_colors=c,process=False)
        T=np.eye(4);T[:3,3]=PIV[part];sc.add_geometry(mesh,node_name=part,geom_name=part,transform=T)
    return sc
def add_glb_locators(glb):
    """Add meshless nodes as children of the existing pivot nodes."""
    magic, version, file_size, json_size, json_type = struct.unpack_from("<4sIII4s", glb)
    if (magic, version, file_size, json_type) != (b"glTF", 2, len(glb), b"JSON"):
        raise ValueError("expected a glTF 2.0 binary with a leading JSON chunk")
    json_end = 20 + json_size
    document = json.loads(glb[20:json_end])
    part_nodes = {node["name"]: node for node in document["nodes"] if "mesh" in node}
    for name, (parent, offset) in LOCATORS.items():
        part_nodes[parent].setdefault("children", []).append(len(document["nodes"]))
        document["nodes"].append({"name": name, "translation": offset})

    json_chunk = json.dumps(document, separators=(",", ":")).encode("utf-8")
    json_chunk += b" " * (-len(json_chunk) % 4)
    remaining_chunks = glb[json_end:]
    file_size = 20 + len(json_chunk) + len(remaining_chunks)
    header = struct.pack("<4sIII4s", b"glTF", 2, file_size, len(json_chunk), b"JSON")
    return header + json_chunk + remaining_chunks


def rust_locator_lines():
    """Emit the same parent-relative offsets for the native renderer."""
    names = {name: name.title().replace("_", "") for name in LOCATORS}
    lines = [
        "/// Rider attachment points on the cruiser.",
        "#[derive(Clone, Copy, Debug, Eq, PartialEq)]",
        "pub enum MotorcycleLocator {",
    ]
    lines.extend(f"    {variant}," for variant in names.values())
    lines.extend([
        "}",
        "",
        "/// Parent part and offset from its pivot, in model meters.",
        "#[must_use]",
        "pub fn motorcycle_locator(locator: MotorcycleLocator) -> (MotorcyclePart, Vec3) {",
        "    match locator {",
    ])
    for name, (parent, offset) in LOCATORS.items():
        part = parent.title().replace("_", "")
        x, y, z = offset
        lines.append(
            f"        MotorcycleLocator::{names[name]} => "
            f"(MotorcyclePart::{part}, Vec3::new({x}, {y}, {z})),"
        )
    lines.extend(["    }", "}"])
    return lines


for name in SCHEMES:
    glb = scene_for(name).export(file_type="glb")
    (OUT / f"cruiser_{name}.glb").write_bytes(add_glb_locators(glb))
# Rust output: indexed positions, material-tagged triangles, flat normals via native builder.
rs=['//! Original Aero-inspired cruiser mesh. Y up, +Z forward, meters. Generated by generate_motorcycle_mesh.py.', '#![allow(clippy::excessive_precision)]','use super::{GeometryTag, MeshBuffer, MeshBuilder, VertexMeta, WorldVertex};','use glam::{Mat4, Vec3};','#[derive(Clone, Copy, Debug, Eq, PartialEq)]','pub enum MotorcyclePart { Body, Steering, FrontWheel, RearWheel }','#[derive(Clone, Copy, Debug, Eq, PartialEq, Default)]','pub enum MotorcyclePaint { #[default] GreenBlack, BurgundyBlack, CreamBlack, MidnightBlue, MatteBlack }','impl MotorcyclePaint {','    pub fn palette(self) -> [[u8; 3]; 3] {','        match self {']
variants=['GreenBlack','BurgundyBlack','CreamBlack','MidnightBlue','MatteBlack'];partnames=['Body','Steering','FrontWheel','RearWheel']
for v,k in zip(variants,SCHEMES):rs.append(f'            Self::{v} => {SCHEMES[k]},'.replace('(','[').replace(')',']'))
rs+=['        }','    }','}', 'const FIXED: [[u8; 3]; '+str(len(COLORS)-3)+'] = '+str(COLORS[3:]).replace('(','[').replace(')',']')+';', 'pub fn motorcycle_part_pivot(part: MotorcyclePart) -> Vec3 {','    match part {']
def fl(x):return f'{float(x):.6f}'
for name,p in zip(partnames,P):rs.append(f'        MotorcyclePart::{name} => Vec3::new({", ".join(map(fl,PIV[p]))}),')
rs+=['    }','}', 'type Face = (u32, u32, u32, u8);','pub fn motorcycle_part_mesh(part: MotorcyclePart, paint: MotorcyclePaint) -> MeshBuffer {','    let (points, faces): (&[[f32; 3]], &[Face]) = match part {']
for name,p in zip(partnames,P):rs.append(f'        MotorcyclePart::{name} => ({p.upper()}_POINTS, {p.upper()}_FACES),')
rs+=['    };','    let palette = paint.palette();','    let meta = VertexMeta::DEFAULT.with_tag(GeometryTag::Prop);','    let mut b = MeshBuilder::with_capacity(faces.len()*3, faces.len()*3);','    for &(a,c,d,m) in faces {','        let [r,g,blue] = if m < 3 { palette[m as usize] } else { FIXED[m as usize - 3] };','        b.push_triangle(Vec3::from_array(points[a as usize]), Vec3::from_array(points[c as usize]), Vec3::from_array(points[d as usize]), WorldVertex::rgba8(r,g,blue,255), meta);','    }','    b.build()','}', 'pub fn motorcycle_mesh(paint: MotorcyclePaint) -> MeshBuffer {','    let mut mesh = MeshBuffer::new();','    for part in [MotorcyclePart::Body, MotorcyclePart::Steering, MotorcyclePart::FrontWheel, MotorcyclePart::RearWheel] {','        mesh.append_transformed(&motorcycle_part_mesh(part, paint), Mat4::from_translation(motorcycle_part_pivot(part)));','    }','    mesh','}']
rs.extend(rust_locator_lines())
for p,items in P.items():
    points=[];mapping={};faces=[]
    for a,m in items:
        idx=[]
        for v in a:
            key=tuple(v)
            if key not in mapping:mapping[key]=len(points);points.append(key)
            idx.append(mapping[key])
        faces.append((*idx,m))
    rs.append(f'const {p.upper()}_POINTS: &[[f32; 3]] = &[')
    rs.extend('    ['+', '.join(map(fl,v))+'],' for v in points);rs.append('];')
    rs.append(f'const {p.upper()}_FACES: &[Face] = &[');rs.extend('    ('+', '.join(map(str,f))+'),' for f in faces);rs.append('];')
(OUT/'motorcycle.rs').write_text('\n'.join(rs)+'\n')
# Software rasterizer with per-face light and z buffer; previews are actual mesh projections.
def preview(name,eye,size=(900,600)):
    pal=np.array(palette(name));v=[];m=[]
    for p,items in P.items():
        for a,c in items:v.append(a+PIV[p]);m.append(c)
    a=np.array(v);m=np.array(m);n=np.cross(a[:,1]-a[:,0],a[:,2]-a[:,0]);n/=np.linalg.norm(n,axis=1)[:,None]
    view=unit(eye);right=unit(np.cross([0,1,0],view));up=np.cross(view,right);x=a@right;y=a@up;z=a@view
    W,H=size;scale=min((W-90)/(x.max()-x.min()),(H-100)/(y.max()-y.min()));x=(x-(x.max()+x.min())/2)*scale+W/2;y=-(y-(y.max()+y.min())/2)*scale+H/2
    img=np.full((H,W,3),[35,39,43],dtype=np.uint8);zb=np.full((H,W),-np.inf);light=unit([.6,1,.65]);light2=unit([-.7,.4,-.3]);shade=.49+.48*np.maximum(0,n@light)+.12*np.maximum(0,n@light2);colors=np.clip(pal[m]*shade[:,None],0,255).astype(np.uint8)
    for i in np.where(n@view>0)[0]:
        xx,yy,zz=x[i],y[i],z[i];xl=max(0,int(np.floor(xx.min())));xh=min(W-1,int(np.ceil(xx.max())));yl=max(0,int(np.floor(yy.min())));yh=min(H-1,int(np.ceil(yy.max())))
        if xh<xl or yh<yl:continue
        X,Y=np.meshgrid(np.arange(xl,xh+1)+.5,np.arange(yl,yh+1)+.5);den=(yy[1]-yy[2])*(xx[0]-xx[2])+(xx[2]-xx[1])*(yy[0]-yy[2]);
        if abs(den)<1e-8:continue
        u=((yy[1]-yy[2])*(X-xx[2])+(xx[2]-xx[1])*(Y-yy[2]))/den;w=((yy[2]-yy[0])*(X-xx[2])+(xx[0]-xx[2])*(Y-yy[2]))/den;t=1-u-w;depth=u*zz[0]+w*zz[1]+t*zz[2];sub=zb[yl:yh+1,xl:xh+1];mask=(u>=0)&(w>=0)&(t>=0)&(depth>sub);sub[mask]=depth[mask];img[yl:yh+1,xl:xh+1][mask]=colors[i]
    return Image.fromarray(img)
preview('green_black',[1,.52,.72]).save(OUT/'cruiser_preview.png')
preview('green_black',[1,.12,0]).save(OUT/'cruiser_side.png')
canvas=Image.new('RGB',(1000,660),(35,39,43));d=ImageDraw.Draw(canvas)
for i,name in enumerate(SCHEMES):
    im=preview(name,[1,.4,.5],(330,285));x=(i%3)*333;y=(i//3)*330;canvas.paste(im,(x,y));d.text((x+14,y+285),name.replace('_',' ').title(),fill=(225,225,225))
canvas.save(OUT/'paint_variants.png')
allv=np.concatenate([a+PIV[p] for p,items in P.items() for a,m in items]);stats={'triangles':{p:len(items) for p,items in P.items()},'bounds_m': [allv.min(0).tolist(),allv.max(0).tolist()], 'pivots_m':PIV,'steering_axis':unit([0,.65,-.36]).tolist()}
stats["locators_m"] = {
    name: {"parent": parent, "offset_m": offset}
    for name, (parent, offset) in LOCATORS.items()
}
print(json.dumps(stats, indent=2))
(OUT / "mesh_stats.json").write_text(json.dumps(stats, indent=2))
