# Zombiebox – Aero-inspired cruiser

An original 1990s Japanese cruiser, loosely inspired by the 1999 Honda Shadow Aero VT1100C3. No brand logos, textures, or external mesh dependencies. Geometry has faceted normals and per-face colors in the style of Zombiebox's native renderer.

## Files
- `motorcycle.rs`: native mesh module for `crates/zombiebox-render3d/src/mesh/`.
- `generate_motorcycle_mesh.py`: reproducible generator; requires NumPy, trimesh and Pillow. Run `python3 generate_motorcycle_mesh.py [output-dir]`.
- `cruiser_*.glb`: five glTF 2.0 binary models with vertex colors and rider locators.
- PNGs: software-rendered views of the same mesh, not concept art.
- `mesh_stats.json`: counts, bounds, pivots, and parent-relative rider locators.

## Rust integration
1. Copy `motorcycle.rs` into `crates/zombiebox-render3d/src/mesh/`.
2. Add `pub mod motorcycle;` to `mesh/mod.rs`.
3. Use the existing MeshBuffer upload/instancing path. Example:

```rust
use crate::mesh::motorcycle::{motorcycle_mesh, MotorcyclePaint};
let mesh = motorcycle_mesh(MotorcyclePaint::GreenBlack);
mesh.validate().expect("valid cruiser mesh");
```

For moving vehicles use `motorcycle_part_mesh(part, paint)` and `motorcycle_part_pivot(part)`. Cache the geometry for each part/paint combination; do not rebuild per frame. Meshes are local to each named pivot. The whole-vehicle helper assembles the rest pose. All parts use `GeometryTag::Prop`; adjust metadata if vehicle-specific shading or visibility is needed. No vehicle simulation, collision shape, renderer registration, or movement is implemented.

## Coordinates and animation
Y up, +Z forward, and model -X toward rider-right in Zombiebox, with dimensions approximately 2.49 m long × 0.99 m wide × 1.40 m high. Body origin at ground level midway between axles. Wheelbase 1.67 m. If engine world units differ from meters, scale the model and pivot offsets uniformly.

| Part | Rest pivot (x,y,z) in meters |
| --- | --- |
| Body | (0,0,0) |
| Steering | (0,0.99,0.48) |
| FrontWheel | (0,0.35,0.835) |
| RearWheel | (0,0.345,-0.835) |

Wheel spin is about local X. Steering rotates around the normalized local axis (0,0.874791,-0.484500). The four GLB mesh nodes are siblings. Compose front wheel steering in the renderer. For column-vector matrices, with world vehicle transform M, steering pivot S, axle pivots F/R, steering rotation A and wheel spin rotation W:

- Body: M
- Steering: M * T(S) * A
- Front wheel: M * T(S) * A * T(F-S) * W_front
- Rear wheel: M * T(R) * W_rear

All GLBs have four mesh nodes at their rest pivots, with vertex colors for the paint and material details.

## Rider locators

The GLBs include five meshless child nodes. Rust exposes the same points through
`motorcycle_locator(MotorcycleLocator)`, which returns the parent part and
its local offset. Transform each point by its parent part's model matrix.
The grips follow the fork, while the seat and footboards follow the chassis.

| GLB node | Parent | Local offset in model meters (x, y, z) |
| --- | --- | --- |
| `seat` | `body` | (0, 0.752, -0.34) |
| `grip_left` | `steering` | (0.3875, 0.19, -0.2625) |
| `grip_right` | `steering` | (-0.3875, 0.19, -0.2625) |
| `footboard_left` | `body` | (0.224, 0.303, 0.16) |
| `footboard_right` | `body` | (-0.224, 0.303, 0.16) |

## Validation / limitations
All five GLBs were reloaded and checked for finite vertices, four meshes, and nondegenerate triangles (cross product squared > 1e-12). Each has 14,880 triangles. The Rust mesh parts and assembled paints passed the renderer's mesh validation in a temporary checkout. The pack has one detail level. Rider fit and frame pacing can be checked when the vehicle renderer is integrated.
